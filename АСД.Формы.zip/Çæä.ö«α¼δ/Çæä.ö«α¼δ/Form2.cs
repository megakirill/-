﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace АСД.Формы
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.CheckedItems[0].ToString() == "Дюймы")
            {
                textBox1.Text = (Form1.num / 2.54).ToString();
            }
            else if (checkedListBox1.CheckedItems[0].ToString() == "Футы")
            {
                textBox1.Text = (Form1.num / 30.48).ToString();
            }
            else if (checkedListBox1.CheckedItems[0].ToString() == "Ярды")
            {
                textBox1.Text = (Form1.num / 91.44).ToString();
            }
            else if (checkedListBox1.CheckedItems[0].ToString() == "Лиги")
            {
                textBox1.Text = (Form1.num / 418000).ToString();
            }
            else if (checkedListBox1.CheckedItems[0].ToString() == "Мили")
            {
                textBox1.Text = (Form1.num / 160934.4).ToString();
            }
        }
    }
}
