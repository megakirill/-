﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace АСД.Формы
{
    public partial class Form1 : Form
    {
        public static double num;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(checkedListBox1.CheckedItems[0].ToString() == "См")
            {
                num = 1 * int.Parse(textBox1.Text);
            }
            else if (checkedListBox1.CheckedItems[0].ToString() == "М")
            {
                num = 100 * int.Parse(textBox1.Text);
            }
            else if (checkedListBox1.CheckedItems[0].ToString() == "Км")
            {
                num = 100000 * int.Parse(textBox1.Text);
            }
            Form2 newform = new Form2();
            newform.Show();
        }
    }
}
